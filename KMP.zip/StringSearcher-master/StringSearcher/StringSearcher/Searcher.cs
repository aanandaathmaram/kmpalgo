﻿using System;
using System.Collections.Generic;


namespace StringSearcher
{
    interface Searcher
    {
        List<int> Search(String pattern, String text);
        void ClearIndexes();
    }
}
