﻿using System;
using System.Collections.Generic;

namespace StringSearcher
{
    class KnuthMorrisPrattSearcher : Searcher
    {
        List<int> start_index;
        List<int> backward_transition_states;

        public KnuthMorrisPrattSearcher()
        {
            backward_transition_states = new List<int>();
            start_index = new List<int>();
        }

        private void InitializeBackwardStates(String pattern)
        {
            backward_transition_states.Add(0);      //the length of an empty string               
            backward_transition_states.Add(0);      //prefix frame length of length 1

            for (int i = 2; i <= pattern.Length; i++)   //for a prefix pattern
            {
                int j = backward_transition_states[i - 1];      //frame length of the previous prefix

                while (true)
                {
                    if (pattern[i - 1] == pattern[j])             // the case when the prefix frame of length i is larger than the prefix frame of length i-1
                    {
                        j++;
                        backward_transition_states.Add(j);
                        break;
                    }
                    if (j == 0)         //the case when the box for the length prefix is ​​an empty word

                    {
                        backward_transition_states.Add(0);
                        break;
                    }
                    j = backward_transition_states[j];              //if the prefix frame of length i is not larger than the frame for prefixes of length i-1
                                                                //there is still the possibility that there is a prefix frame of length i that is smaller than a prefix frame of length i-1
                                                //the length of the next largest prefix frame of length i-1 is located at position backward_transition_states[j]
                                                    //in the next iteration, that frame is tried with expansion to match the prefix frame of length i
                }
            }
        }

        public List<int> Search(String pattern, String text)
        {
            if (text.Length < pattern.Length || pattern.Length == 0)
                return start_index;

            InitializeBackwardStates(pattern);

            int i = 0;      //the position of the next letter from the text to be read
            int j = 0;      //the state of the simulated automaton
            while (i < text.Length)
            {
                if (text[i] == pattern[j])      //forward transition function
                {
                    i++;
                    j++;
                    if (j == pattern.Length)     //recognized pattern
                    {
                        j = backward_transition_states[j];      //we move the automaton backwards so that it corresponds to the recognized prefix, which is the largest frame of the //backward transition function pattern
                        start_index.Add(i - pattern.Length);      //the position within the text where we found the pattern
                    }
                }
                else
                    if (j > 0)          
                        j = backward_transition_states[j];          //backward transition function
                    else
                        i++;                    //backward transition function is not possible, not a single prefix is ​​recognized, transition to the next part of the text
            }
            return start_index;
        }


        public void ClearIndexes()
        {
            start_index.Clear();
            backward_transition_states.Clear();
        }
    }
}
