﻿namespace StringSearcher
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox_AlgorithmSelection = new System.Windows.Forms.GroupBox();
            this.radioButton_Knuth_Morris_Pratt_Search = new System.Windows.Forms.RadioButton();
            this.button_Search = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox_Text = new System.Windows.Forms.RichTextBox();
            this.button_LoadText = new System.Windows.Forms.Button();
            this.textBox_Pattern = new System.Windows.Forms.RichTextBox();
            this.label_Message = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label_RobinKarpSimulatoMessage = new System.Windows.Forms.Label();
            this.button_SetBlackText = new System.Windows.Forms.Button();
            this.groupBox_AlgorithmSelection.SuspendLayout();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(3, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(52, 16);
            this.label1.TabIndex = 26;
            this.label1.Text = "Pattern:";
            // 
            // groupBox_AlgorithmSelection
            // 
            this.groupBox_AlgorithmSelection.Controls.Add(this.radioButton_Knuth_Morris_Pratt_Search);
            this.groupBox_AlgorithmSelection.Location = new System.Drawing.Point(8, 12);
            this.groupBox_AlgorithmSelection.Name = "groupBox_AlgorithmSelection";
            this.groupBox_AlgorithmSelection.Size = new System.Drawing.Size(464, 67);
            this.groupBox_AlgorithmSelection.TabIndex = 3;
            this.groupBox_AlgorithmSelection.TabStop = false;
            this.groupBox_AlgorithmSelection.Text = "Algorithm";
            // 
            // radioButton_Knuth_Morris_Pratt_Search
            // 
            this.radioButton_Knuth_Morris_Pratt_Search.AutoSize = true;
            this.radioButton_Knuth_Morris_Pratt_Search.Location = new System.Drawing.Point(7, 27);
            this.radioButton_Knuth_Morris_Pratt_Search.Name = "radioButton_Knuth_Morris_Pratt_Search";
            this.radioButton_Knuth_Morris_Pratt_Search.Size = new System.Drawing.Size(132, 20);
            this.radioButton_Knuth_Morris_Pratt_Search.TabIndex = 6;
            this.radioButton_Knuth_Morris_Pratt_Search.Text = "Knuth-Morris-Pratt";
            this.radioButton_Knuth_Morris_Pratt_Search.UseVisualStyleBackColor = true;
            this.radioButton_Knuth_Morris_Pratt_Search.CheckedChanged += new System.EventHandler(this.radioButton_Knuth_Morris_Pratt_Search_CheckedChanged);
            // 
            // button_Search
            // 
            this.button_Search.Location = new System.Drawing.Point(305, 20);
            this.button_Search.Name = "button_Search";
            this.button_Search.Size = new System.Drawing.Size(140, 27);
            this.button_Search.TabIndex = 3;
            this.button_Search.Text = "Search";
            this.button_Search.UseVisualStyleBackColor = true;
            this.button_Search.Click += new System.EventHandler(this.button_Search_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(5, 163);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(36, 16);
            this.label2.TabIndex = 25;
            this.label2.Text = "Text:";
            // 
            // textBox_Text
            // 
            this.textBox_Text.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox_Text.Location = new System.Drawing.Point(8, 192);
            this.textBox_Text.Name = "textBox_Text";
            this.textBox_Text.ScrollBars = System.Windows.Forms.RichTextBoxScrollBars.Vertical;
            this.textBox_Text.Size = new System.Drawing.Size(1120, 478);
            this.textBox_Text.TabIndex = 2;
            this.textBox_Text.Text = "";
            // 
            // button_LoadText
            // 
            this.button_LoadText.Location = new System.Drawing.Point(981, 676);
            this.button_LoadText.Name = "button_LoadText";
            this.button_LoadText.Size = new System.Drawing.Size(140, 27);
            this.button_LoadText.TabIndex = 11;
            this.button_LoadText.Text = "Load Text";
            this.button_LoadText.UseVisualStyleBackColor = true;
            this.button_LoadText.Click += new System.EventHandler(this.button_LoadText_Click);
            // 
            // textBox_Pattern
            // 
            this.textBox_Pattern.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.textBox_Pattern.Location = new System.Drawing.Point(6, 20);
            this.textBox_Pattern.Multiline = false;
            this.textBox_Pattern.Name = "textBox_Pattern";
            this.textBox_Pattern.Size = new System.Drawing.Size(280, 28);
            this.textBox_Pattern.TabIndex = 1;
            this.textBox_Pattern.Text = "";
            // 
            // label_Message
            // 
            this.label_Message.AutoSize = true;
            this.label_Message.Location = new System.Drawing.Point(12, 775);
            this.label_Message.Name = "label_Message";
            this.label_Message.Size = new System.Drawing.Size(0, 16);
            this.label_Message.TabIndex = 24;
            this.label_Message.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.textBox_Pattern);
            this.panel2.Controls.Add(this.label1);
            this.panel2.Controls.Add(this.button_Search);
            this.panel2.Location = new System.Drawing.Point(8, 88);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(464, 55);
            this.panel2.TabIndex = 18;
            // 
            // label_RobinKarpSimulatoMessage
            // 
            this.label_RobinKarpSimulatoMessage.AutoSize = true;
            this.label_RobinKarpSimulatoMessage.Location = new System.Drawing.Point(481, 226);
            this.label_RobinKarpSimulatoMessage.Name = "label_RobinKarpSimulatoMessage";
            this.label_RobinKarpSimulatoMessage.Size = new System.Drawing.Size(0, 16);
            this.label_RobinKarpSimulatoMessage.TabIndex = 27;
            // 
            // button_SetBlackText
            // 
            this.button_SetBlackText.Location = new System.Drawing.Point(835, 676);
            this.button_SetBlackText.Name = "button_SetBlackText";
            this.button_SetBlackText.Size = new System.Drawing.Size(140, 27);
            this.button_SetBlackText.TabIndex = 12;
            this.button_SetBlackText.Text = "Black Text";
            this.button_SetBlackText.UseVisualStyleBackColor = true;
            this.button_SetBlackText.Click += new System.EventHandler(this.button_SetBlackText_Click);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1135, 803);
            this.Controls.Add(this.button_SetBlackText);
            this.Controls.Add(this.label_RobinKarpSimulatoMessage);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.label_Message);
            this.Controls.Add(this.button_LoadText);
            this.Controls.Add(this.textBox_Text);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.groupBox_AlgorithmSelection);
            this.MaximumSize = new System.Drawing.Size(1153, 850);
            this.MinimumSize = new System.Drawing.Size(1153, 850);
            this.Name = "MainForm";
            this.Text = "StringSearcher";
            this.groupBox_AlgorithmSelection.ResumeLayout(false);
            this.groupBox_AlgorithmSelection.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox_AlgorithmSelection;
        private System.Windows.Forms.RadioButton radioButton_Knuth_Morris_Pratt_Search;
        private System.Windows.Forms.Button button_Search;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.RichTextBox textBox_Text;
        private System.Windows.Forms.Button button_LoadText;
        private System.Windows.Forms.RichTextBox textBox_Pattern;
        private System.Windows.Forms.Label label_Message;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label_RobinKarpSimulatoMessage;
        private System.Windows.Forms.Button button_SetBlackText;
    }
}

