﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StringSearcher
{
    public partial class MainForm : Form
    {
        Searcher searcher;
        KnuthMorrisPrattSearcher knuth_morris_pratt_searcher;

        Simulator simulator;
        KnuthMorrisPrattSimulator knuth_morris_pratt_simulator;

        List<int> start_indexes;

        public MainForm()
        {
            //components
            InitializeComponent();
           
            //searcher-i
            knuth_morris_pratt_searcher = new KnuthMorrisPrattSearcher();

            //simulator-i
            knuth_morris_pratt_simulator = new KnuthMorrisPrattSimulator(textBox_Pattern, textBox_Text, label_RobinKarpSimulatoMessage);

            //default-ni searcher i simulator;
            
            start_indexes = new List<int>();
        }

        private void SelectSeracher(bool knuth_morris_pratt)
        {
            searcher = (Searcher)knuth_morris_pratt_searcher;
        }

        private void SelectSimulator(bool knuth_morris_pratt)
        {
            simulator = (Simulator)knuth_morris_pratt_simulator;
        }

        private void button_Search_Click(object sender, EventArgs e)
        {
            if (textBox_Pattern.Text.Length > textBox_Text.Text.Length)
            {
                MessageBox.Show("Pattern must be shorter than text!!", "Error");
                return;
            }
            if (textBox_Pattern.Text.Length == 0 || textBox_Text.Text.Length == 0)
            {
                MessageBox.Show("Please enter pattern and text!!", "Error");
                return;
            }

            SelectSeracher(radioButton_Knuth_Morris_Pratt_Search.Checked);

            start_indexes = searcher.Search(textBox_Pattern.Text, textBox_Text.Text);
            textBox_Text.Select(0, textBox_Text.Text.Length);
            textBox_Text.SelectionColor = Color.Black;

            foreach (int index in start_indexes)
            {
                textBox_Text.Select(index, textBox_Pattern.Text.Length);
                textBox_Text.SelectionColor = Color.Red;
            }

            string plural_or_not;
            if (start_indexes.Count == 1)
                plural_or_not = "";
            else
                plural_or_not = "es";
            label_Message.Text = "Found: " + start_indexes.Count.ToString() + " match"+plural_or_not;

            searcher.ClearIndexes();
            start_indexes.Clear();
        }

        /// <summary>
        ///     A file dialog opens in which a text document can be selected
        ///     the text document is loaded and serves as the text in which the appearance of the pattern is requested
        /// </summary>
        private void button_LoadText_Click(object sender, EventArgs e)
        {
            OpenFileDialog file_dialog = new OpenFileDialog();
            file_dialog.Filter = "text files| *.txt";

            if (file_dialog.ShowDialog() == DialogResult.OK)
            {
                textBox_Text.Text = System.IO.File.ReadAllText(file_dialog.FileName);
            }

            textBox_Text.Select(0, textBox_Text.Text.Length);
            textBox_Text.SelectionColor = Color.Black;
        }


        private void button_SimulationStart_Click(object sender, EventArgs e)
        {
            if (textBox_Pattern.Text.Length > textBox_Text.Text.Length)
            {
                MessageBox.Show("Pattern must be shorter than text!!","Error");
                return;
            }
            if (textBox_Pattern.Text.Length == 0 || textBox_Text.Text.Length==0)
            {
                MessageBox.Show("Please enter pattern and text!!", "Error");
                return;
            }

            groupBox_AlgorithmSelection.Enabled = false;

            button_SetBlackText.Visible = false;

            textBox_Pattern.ReadOnly = true;
            textBox_Text.ReadOnly = true;

            label_Message.Text = "Simulation running. To exit simulation mode, press Restart.";

            simulator.SetPatternAndText();
            simulator.Prepare();
        }

      
        private void button_SimulationNextStep_Click(object sender, EventArgs e)
        {
            simulator.NextStep();
        }

        private void radioButton_Knuth_Morris_Pratt_Search_CheckedChanged(object sender, EventArgs e)
        {
            if (radioButton_Knuth_Morris_Pratt_Search.Checked)
            {
                SelectSimulator(true);
            }
        }

        private void button_SetBlackText_Click(object sender, EventArgs e)
        {
            textBox_Text.Select(0, textBox_Text.Text.Length);
            textBox_Text.SelectionColor = Color.Black;
        }
    }
}
